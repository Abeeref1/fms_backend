from flask import Blueprint, request, jsonify
from .. import db
from ..models import Manpower, School
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

manpower_bp = Blueprint("manpower_bp", __name__, url_prefix="/api/v1/manpower")

@manpower_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view manpower list
def get_manpower_list():
    manpower_list = Manpower.query.all()
    return jsonify([m.to_dict() for m in manpower_list])

@manpower_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create manpower records
def create_manpower():
    data = request.get_json()
    if not data or not data.get("name") or not data.get("role"):
        return jsonify({"error": "Name and role are required"}), 400

    if data.get("assigned_school_id"):
        school = School.query.get(data["assigned_school_id"])
        if not school:
            return jsonify({"error": "Assigned school not found"}), 404

    new_manpower = Manpower(
        name=data["name"],
        role=data["role"],
        skill_level=data.get("skill_level"),
        hourly_rate=data.get("hourly_rate"),
        assigned_school_id=data.get("assigned_school_id")
    )
    db.session.add(new_manpower)
    db.session.commit()
    return jsonify(new_manpower.to_dict()), 201

@manpower_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view specific manpower details
def get_manpower(id):
    manpower = Manpower.query.get_or_404(id)
    return jsonify(manpower.to_dict())

@manpower_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update manpower records
def update_manpower(id):
    manpower = Manpower.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        manpower.name = data["name"]
    if "role" in data:
        manpower.role = data["role"]
    if "skill_level" in data:
        manpower.skill_level = data["skill_level"]
    if "hourly_rate" in data:
        manpower.hourly_rate = data["hourly_rate"]
    if "assigned_school_id" in data:
        if data["assigned_school_id"]:
            school = School.query.get(data["assigned_school_id"])
            if not school:
                return jsonify({"error": "Assigned school not found"}), 404
        manpower.assigned_school_id = data["assigned_school_id"]

    db.session.commit()
    return jsonify(manpower.to_dict())

@manpower_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete manpower records
def delete_manpower(id):
    manpower = Manpower.query.get_or_404(id)
    # Add check for assigned work orders if needed
    db.session.delete(manpower)
    db.session.commit()
    return jsonify({"message": "Manpower record deleted successfully"})

