# src/routes/notification_routes.py
from flask import Blueprint, jsonify, request, current_app
from .. import db
from ..models import Notification
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

notification_bp = Blueprint("notification_bp", __name__, url_prefix="/api/v1/notifications")

@notification_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view their notifications
def get_notifications():
    """Fetches notifications, optionally filtering by read status."""
    try:
        # TODO: Filter by current_user.id when user association is added to Notification model
        show_read = request.args.get("show_read", "false").lower() == "true"
        limit = request.args.get("limit", 10, type=int)

        query = Notification.query
        if not show_read:
            query = query.filter_by(is_read=False)
        
        notifications = query.order_by(Notification.created_at.desc()).limit(limit).all()
        
        return jsonify([n.to_dict() for n in notifications])
    except Exception as e:
        current_app.logger.error(f"Error fetching notifications: {e}")
        return jsonify({"error": "Failed to fetch notifications", "details": str(e)}), 500

@notification_bp.route("/<int:id>/read", methods=["PATCH"])
@technician_required # All authenticated users can mark their notifications as read
def mark_notification_as_read(id):
    """Marks a specific notification as read."""
    try:
        # TODO: Add check to ensure notification belongs to current_user
        notification = Notification.query.get_or_404(id)
        notification.is_read = True
        db.session.commit()
        return jsonify(notification.to_dict())
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error marking notification {id} as read: {e}")
        return jsonify({"error": "Failed to mark notification as read", "details": str(e)}), 500

@notification_bp.route("/read_all", methods=["PATCH"])
@technician_required # All authenticated users can mark all their notifications as read
def mark_all_notifications_as_read():
    """Marks all unread notifications as read (for the current user - placeholder)."""
    try:
        # TODO: Filter by current_user.id when user association is added
        unread_notifications = Notification.query.filter_by(is_read=False).all()
        count = 0
        for notification in unread_notifications:
            notification.is_read = True
            count += 1
        
        db.session.commit()
        return jsonify({"message": f"Marked {count} notifications as read."})
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error marking all notifications as read: {e}")
        return jsonify({"error": "Failed to mark all notifications as read", "details": str(e)}), 500

# Note: Notification creation is likely handled internally by other backend processes
# when specific events occur (e.g., work order completion, SLA breach).
# A public POST endpoint might not be needed unless users can create custom notifications.

