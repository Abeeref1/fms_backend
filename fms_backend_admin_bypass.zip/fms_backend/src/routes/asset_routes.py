from flask import Blueprint, request, jsonify
from .. import db
from ..models import Asset, School
from datetime import date
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

asset_bp = Blueprint("asset_bp", __name__, url_prefix="/api/v1/assets")

@asset_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view assets
def get_assets():
    assets = Asset.query.all()
    return jsonify([asset.to_dict() for asset in assets])

@asset_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create assets
def create_asset():
    data = request.get_json()
    if not data or not data.get("name") or not data.get("asset_type") or not data.get("school_id"):
        return jsonify({"error": "Name, asset_type, and school_id are required"}), 400

    school = School.query.get(data["school_id"])
    if not school:
        return jsonify({"error": "School not found"}), 404

    # Optional: Check for unique serial number if provided
    if data.get("serial_number"):
        existing_asset = Asset.query.filter_by(serial_number=data["serial_number"]).first()
        if existing_asset:
            return jsonify({"error": "Serial number must be unique"}), 400

    try:
        installation_date = date.fromisoformat(data["installation_date"]) if data.get("installation_date") else None
        warranty_expiry_date = date.fromisoformat(data["warranty_expiry_date"]) if data.get("warranty_expiry_date") else None
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid date format. Use YYYY-MM-DD."}), 400

    new_asset = Asset(
        name=data["name"],
        asset_type=data["asset_type"],
        location=data.get("location"),
        manufacturer=data.get("manufacturer"),
        model_number=data.get("model_number"),
        serial_number=data.get("serial_number"),
        installation_date=installation_date,
        warranty_expiry_date=warranty_expiry_date,
        status=data.get("status", "Operational"),
        school_id=data["school_id"]
    )
    db.session.add(new_asset)
    db.session.commit()
    return jsonify(new_asset.to_dict()), 201

@asset_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific asset
def get_asset(id):
    asset = Asset.query.get_or_404(id)
    return jsonify(asset.to_dict())

@asset_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update assets
def update_asset(id):
    asset = Asset.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        asset.name = data["name"]
    if "asset_type" in data:
        asset.asset_type = data["asset_type"]
    if "location" in data:
        asset.location = data["location"]
    if "manufacturer" in data:
        asset.manufacturer = data["manufacturer"]
    if "model_number" in data:
        asset.model_number = data["model_number"]
    if "serial_number" in data:
        if data["serial_number"] != asset.serial_number:
            existing_asset = Asset.query.filter_by(serial_number=data["serial_number"]).first()
            if existing_asset:
                return jsonify({"error": "Serial number must be unique"}), 400
        asset.serial_number = data["serial_number"]
    if "installation_date" in data:
        try:
            asset.installation_date = date.fromisoformat(data["installation_date"]) if data["installation_date"] else None
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid installation_date format. Use YYYY-MM-DD."}), 400
    if "warranty_expiry_date" in data:
        try:
            asset.warranty_expiry_date = date.fromisoformat(data["warranty_expiry_date"]) if data["warranty_expiry_date"] else None
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid warranty_expiry_date format. Use YYYY-MM-DD."}), 400
    if "status" in data:
        asset.status = data["status"]
    if "school_id" in data:
        school = School.query.get(data["school_id"])
        if not school:
            return jsonify({"error": "School not found"}), 404
        asset.school_id = data["school_id"]

    db.session.commit()
    return jsonify(asset.to_dict())

@asset_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete assets
def delete_asset(id):
    asset = Asset.query.get_or_404(id)
    # Add check for associated work orders if needed
    # if asset.work_orders:
    #     return jsonify({"error": "Cannot delete asset with associated work orders"}), 400
    db.session.delete(asset)
    db.session.commit()
    return jsonify({"message": "Asset deleted successfully"})

