from flask import Blueprint, request, jsonify
from .. import db
from ..models import WorkOrder, School, Asset, Manpower
from datetime import date, datetime
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

work_order_bp = Blueprint("work_order_bp", __name__, url_prefix="/api/v1/work-orders")

@work_order_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view work orders
def get_work_orders():
    work_orders = WorkOrder.query.order_by(WorkOrder.created_at.desc()).all()
    return jsonify([wo.to_dict() for wo in work_orders])

@work_order_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create work orders
def create_work_order():
    data = request.get_json()
    if not data or not data.get("description") or not data.get("work_order_type") or not data.get("school_id"):
        return jsonify({"error": "Description, work_order_type, and school_id are required"}), 400

    school = School.query.get(data["school_id"])
    if not school:
        return jsonify({"error": "School not found"}), 404

    asset = None
    if data.get("asset_id"):
        asset = Asset.query.get(data["asset_id"])
        if not asset:
            return jsonify({"error": "Asset not found"}), 404

    technician = None
    if data.get("assigned_technician_id"):
        technician = Manpower.query.get(data["assigned_technician_id"])
        if not technician:
            return jsonify({"error": "Assigned technician not found"}), 404

    try:
        scheduled_date = date.fromisoformat(data["scheduled_date"]) if data.get("scheduled_date") else None
        completion_date = date.fromisoformat(data["completion_date"]) if data.get("completion_date") else None
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid date format. Use YYYY-MM-DD."}), 400

    new_wo = WorkOrder(
        description=data["description"],
        work_order_type=data["work_order_type"],
        priority=data.get("priority", "Medium"),
        status=data.get("status", "Open"),
        scheduled_date=scheduled_date,
        completion_date=completion_date,
        school_id=data["school_id"],
        asset_id=data.get("asset_id"),
        assigned_technician_id=data.get("assigned_technician_id")
    )
    db.session.add(new_wo)
    db.session.commit()
    return jsonify(new_wo.to_dict()), 201

@work_order_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific work order
def get_work_order(id):
    work_order = WorkOrder.query.get_or_404(id)
    return jsonify(work_order.to_dict())

@work_order_bp.route("/<int:id>", methods=["PUT"])
@technician_required # Technicians, Managers, Admins can update work orders (e.g., status)
def update_work_order(id):
    work_order = WorkOrder.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "description" in data:
        work_order.description = data["description"]
    if "work_order_type" in data:
        work_order.work_order_type = data["work_order_type"]
    if "priority" in data:
        work_order.priority = data["priority"]
    if "status" in data:
        work_order.status = data["status"]
    if "scheduled_date" in data:
        try:
            work_order.scheduled_date = date.fromisoformat(data["scheduled_date"]) if data["scheduled_date"] else None
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid scheduled_date format. Use YYYY-MM-DD."}), 400
    if "completion_date" in data:
        try:
            work_order.completion_date = date.fromisoformat(data["completion_date"]) if data["completion_date"] else None
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid completion_date format. Use YYYY-MM-DD."}), 400
    if "school_id" in data:
        school = School.query.get(data["school_id"])
        if not school:
            return jsonify({"error": "School not found"}), 404
        work_order.school_id = data["school_id"]
    if "asset_id" in data:
        if data["asset_id"]:
            asset = Asset.query.get(data["asset_id"])
            if not asset:
                return jsonify({"error": "Asset not found"}), 404
        work_order.asset_id = data["asset_id"]
    if "assigned_technician_id" in data:
        if data["assigned_technician_id"]:
            technician = Manpower.query.get(data["assigned_technician_id"])
            if not technician:
                return jsonify({"error": "Assigned technician not found"}), 404
        work_order.assigned_technician_id = data["assigned_technician_id"]

    db.session.commit()
    return jsonify(work_order.to_dict())

@work_order_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete work orders
def delete_work_order(id):
    work_order = WorkOrder.query.get_or_404(id)
    # Costs are deleted via cascade
    db.session.delete(work_order)
    db.session.commit()
    return jsonify({"message": "Work order deleted successfully"})

