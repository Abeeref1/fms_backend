from .. import db # Import db from parent package (src)

class SLA(db.Model):
    __tablename__ = 'slas'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    metric = db.Column(db.String(100), nullable=False) # e.g., Response Time, Resolution Time, Uptime
    target = db.Column(db.String(50), nullable=False) # e.g., '< 4 hours', '> 99.5%', '100%'
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'), nullable=True) # Optional link to a specific service
    results = db.relationship('SLAResult', backref='sla', lazy=True, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'metric': self.metric,
            'target': self.target,
            'service_id': self.service_id
        }
