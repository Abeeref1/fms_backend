from .. import db # Import db from parent package (src)

class School(db.Model):
    __tablename__ = 'schools'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    address = db.Column(db.Text, nullable=True)
    contact_person = db.Column(db.String(100), nullable=True)
    contact_email = db.Column(db.String(120), nullable=True)
    contact_phone = db.Column(db.String(20), nullable=True)
    region_id = db.Column(db.Integer, db.ForeignKey('regions.id'), nullable=False)
    assets = db.relationship('Asset', backref='school', lazy=True)
    work_orders = db.relationship('WorkOrder', backref='school', lazy=True)
    invoices = db.relationship('Invoice', backref='school', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'address': self.address,
            'contact_person': self.contact_person,
            'contact_email': self.contact_email,
            'contact_phone': self.contact_phone,
            'region_id': self.region_id,
            'region_name': self.region.name if self.region else None
        }
