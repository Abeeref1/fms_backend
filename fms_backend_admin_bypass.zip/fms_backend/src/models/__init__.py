# This file makes the 'models' directory a Python package
# and exposes the model classes for easier import.

from .region import Region
from .school import School
from .stakeholder import Stakeholder
from .asset import Asset
from .manpower import Manpower
from .service import Service
from .work_order import WorkOrder
from .work_order_cost import WorkOrderCost
from .sla import SLA
from .sla_result import SLAResult
from .kpi import KPI
from .kpi_result import KPIResult
from .invoice import Invoice
from .notification import Notification # Import the new Notification model

__all__ = [
    "Region",
    "School",
    "Stakeholder",
    "Asset",
    "Manpower",
    "Service",
    "WorkOrder",
    "WorkOrderCost",
    "SLA",
    "SLAResult",
    "KPI",
    "KPIResult",
    "Invoice",
    "Notification" # Add Notification to the list
]

