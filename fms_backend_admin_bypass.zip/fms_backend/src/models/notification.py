# src/models/notification.py
from .. import db # Import db from the parent package (src)
from datetime import datetime

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=True) # Nullable for system-wide notifications
    message = db.Column(db.String(500), nullable=False)
    type = db.Column(db.String(50), default="info") # e.g., info, warning, error, success
    related_entity_type = db.Column(db.String(50), nullable=True) # e.g., WorkOrder, Invoice
    related_entity_id = db.Column(db.Integer, nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "message": self.message,
            "type": self.type,
            "related_entity_type": self.related_entity_type,
            "related_entity_id": self.related_entity_id,
            "is_read": self.is_read,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

