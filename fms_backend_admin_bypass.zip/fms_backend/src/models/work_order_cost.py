from .. import db # Import db from parent package (src)

class WorkOrderCost(db.Model):
    __tablename__ = 'work_order_costs'
    id = db.Column(db.Integer, primary_key=True)
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), nullable=False)
    cost_type = db.Column(db.String(50), nullable=False) # e.g., Labor, Material, Parts, Subcontractor
    description = db.Column(db.Text, nullable=True)
    amount = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'work_order_id': self.work_order_id,
            'cost_type': self.cost_type,
            'description': self.description,
            'amount': self.amount
        }
