from .. import db # Import db from parent package (src)
from datetime import datetime

class KPIResult(db.Model):
    __tablename__ = 'kpi_results'
    id = db.Column(db.Integer, primary_key=True)
    kpi_id = db.Column(db.Integer, db.ForeignKey('kpis.id'), nullable=False)
    measurement_date = db.Column(db.Date, default=datetime.utcnow, nullable=False)
    value = db.Column(db.Float, nullable=False) # Actual measured value
    notes = db.Column(db.Text, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'kpi_id': self.kpi_id,
            'measurement_date': self.measurement_date.isoformat() if self.measurement_date else None,
            'value': self.value,
            'notes': self.notes
        }
