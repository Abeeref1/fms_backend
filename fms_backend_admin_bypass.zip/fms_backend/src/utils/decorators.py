# src/utils/decorators.py
from functools import wraps
from flask import jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt

def role_required(required_role):
    """Decorator to ensure user has the required role."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                verify_jwt_in_request()
                claims = get_jwt()
                user_role = claims.get("role")

                if user_role != required_role:
                    return jsonify({"error": f"Access forbidden: {required_role} role required"}), 403
                
                return fn(*args, **kwargs)
            except Exception as e:
                # Handle potential JWT errors (e.g., expired token, invalid token)
                # Flask-JWT-Extended might raise specific exceptions we could catch
                return jsonify({"error": f"Authorization error: {str(e)}"}), 401
        return wrapper
    return decorator

def roles_required(required_roles):
    """Decorator to ensure user has one of the required roles."""
    if not isinstance(required_roles, list):
        required_roles = [required_roles] # Ensure it's a list
        
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                verify_jwt_in_request()
                claims = get_jwt()
                user_role = claims.get("role")

                if user_role not in required_roles:
                    roles_str = ", ".join(required_roles)
                    return jsonify({"error": f"Access forbidden: Requires one of the following roles: {roles_str}"}), 403
                
                return fn(*args, **kwargs)
            except Exception as e:
                return jsonify({"error": f"Authorization error: {str(e)}"}), 401
        return wrapper
    return decorator

# Specific role decorators for convenience
admin_required = roles_required(["Admin"])
manager_required = roles_required(["Admin", "Manager"]) # Admins can also do manager tasks
technician_required = roles_required(["Admin", "Manager", "Technician"]) # Admins/Managers can also do technician tasks

