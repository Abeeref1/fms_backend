from .. import db # Import db from parent package (src)

class Service(db.Model):
    __tablename__ = 'services'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False) # e.g., HVAC Maintenance, Cleaning, Security
    description = db.Column(db.Text, nullable=True)
    frequency = db.Column(db.String(50), nullable=True) # e.g., Daily, Weekly, Monthly, Ad-hoc
    cost = db.Column(db.Float, nullable=True) # Base cost if applicable

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'frequency': self.frequency,
            'cost': self.cost
        }
