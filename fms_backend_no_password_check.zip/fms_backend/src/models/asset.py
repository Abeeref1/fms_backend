from .. import db # Import db from parent package (src)
from datetime import datetime

class Asset(db.Model):
    __tablename__ = 'assets'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    asset_type = db.Column(db.String(50), nullable=False) # e.g., HVAC, Plumbing, Electrical, Furniture
    location = db.Column(db.String(100), nullable=True)
    manufacturer = db.Column(db.String(100), nullable=True)
    model_number = db.Column(db.String(100), nullable=True)
    serial_number = db.Column(db.String(100), unique=True, nullable=True)
    installation_date = db.Column(db.Date, nullable=True)
    warranty_expiry_date = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(50), default='Operational') # e.g., Operational, Under Maintenance, Decommissioned
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    work_orders = db.relationship('WorkOrder', backref='asset', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'asset_type': self.asset_type,
            'location': self.location,
            'manufacturer': self.manufacturer,
            'model_number': self.model_number,
            'serial_number': self.serial_number,
            'installation_date': self.installation_date.isoformat() if self.installation_date else None,
            'warranty_expiry_date': self.warranty_expiry_date.isoformat() if self.warranty_expiry_date else None,
            'status': self.status,
            'school_id': self.school_id,
            'school_name': self.school.name if self.school else None
        }
