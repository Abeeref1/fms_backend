from .. import db # Import db from parent package (src)

class Manpower(db.Model):
    __tablename__ = 'manpower'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50), nullable=False) # e.g., Cleaner, Technician, Supervisor
    skill_level = db.Column(db.String(50), nullable=True)
    hourly_rate = db.Column(db.Float, nullable=True) # Placeholder for cost calculation
    assigned_school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'role': self.role,
            'skill_level': self.skill_level,
            'hourly_rate': self.hourly_rate,
            'assigned_school_id': self.assigned_school_id
        }
