from .. import db # Import db from parent package (src)
from datetime import datetime

class WorkOrder(db.Model):
    __tablename__ = 'work_orders'
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.Text, nullable=False)
    work_order_type = db.Column(db.String(50), nullable=False) # e.g., CM (Corrective Maintenance), PPM (Planned Preventive Maintenance)
    priority = db.Column(db.String(50), default='Medium') # e.g., Low, Medium, High, Urgent
    status = db.Column(db.String(50), default='Open') # e.g., Open, In Progress, On Hold, Completed, Closed, Cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    scheduled_date = db.Column(db.Date, nullable=True)
    completion_date = db.Column(db.Date, nullable=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    asset_id = db.Column(db.Integer, db.ForeignKey('assets.id'), nullable=True) # Optional link to a specific asset
    assigned_technician_id = db.Column(db.Integer, db.ForeignKey('manpower.id'), nullable=True)
    costs = db.relationship('WorkOrderCost', backref='work_order', lazy=True, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            'id': self.id,
            'description': self.description,
            'work_order_type': self.work_order_type,
            'priority': self.priority,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'scheduled_date': self.scheduled_date.isoformat() if self.scheduled_date else None,
            'completion_date': self.completion_date.isoformat() if self.completion_date else None,
            'school_id': self.school_id,
            'school_name': self.school.name if self.school else None,
            'asset_id': self.asset_id,
            'asset_name': self.asset.name if self.asset else None,
            'assigned_technician_id': self.assigned_technician_id
        }
