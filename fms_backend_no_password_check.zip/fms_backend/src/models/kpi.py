from .. import db # Import db from parent package (src)

class KPI(db.Model):
    __tablename__ = 'kpis'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    category = db.Column(db.String(100), nullable=False) # e.g., Financial, Operational, Safety, Customer Satisfaction
    measurement_unit = db.Column(db.String(50), nullable=False) # e.g., %, $, Count, Hours
    target_value = db.Column(db.Float, nullable=True)
    target_period = db.Column(db.String(50), nullable=True) # e.g., Monthly, Quarterly, Annually
    results = db.relationship('KPIResult', backref='kpi', lazy=True, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'measurement_unit': self.measurement_unit,
            'target_value': self.target_value,
            'target_period': self.target_period
        }
