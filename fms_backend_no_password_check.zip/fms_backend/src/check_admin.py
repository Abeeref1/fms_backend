#!/home/ubuntu/fms_backend/venv/bin/python
import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import create_app
from src.models import Stakeholder

app = create_app()

with app.app_context():
    admin_email = "admin@example.com"
    admin_user = Stakeholder.query.filter_by(contact_email=admin_email).first()
    
    if admin_user:
        print(f"Admin user found: ID={admin_user.id}, Email={admin_user.contact_email}, Name={admin_user.name}, Role={admin_user.role}, Active={admin_user.is_active}")
        # Check password
        password_to_check = "FM-System-2025!"
        if admin_user.check_password(password_to_check):
            print(f"Password '{password_to_check}' matches for user {admin_email}.")
        else:
            print(f"Password '{password_to_check}' DOES NOT match for user {admin_email}.")
            # Optionally, print the hash if needed for debugging (be careful with sensitive data)
            # print(f"Stored password hash: {admin_user.password_hash}")
    else:
        print(f"Admin user with email '{admin_email}' not found in the database.")

