from flask import Blueprint, request, jsonify
from .. import db
from ..models import Region
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

region_bp = Blueprint("region_bp", __name__, url_prefix="/api/v1/regions")

@region_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view regions
def get_regions():
    regions = Region.query.all()
    return jsonify([region.to_dict() for region in regions])

@region_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create regions
def create_region():
    data = request.get_json()
    if not data or not data.get("name"):
        return jsonify({"error": "Region name is required"}), 400
    
    existing_region = Region.query.filter_by(name=data["name"]).first()
    if existing_region:
        return jsonify({"error": "Region name must be unique"}), 400

    new_region = Region(
        name=data["name"],
        description=data.get("description")
    )
    db.session.add(new_region)
    db.session.commit()
    return jsonify(new_region.to_dict()), 201

@region_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific region
def get_region(id):
    region = Region.query.get_or_404(id)
    return jsonify(region.to_dict())

@region_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update regions
def update_region(id):
    region = Region.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        if data["name"] != region.name:
            existing_region = Region.query.filter_by(name=data["name"]).first()
            if existing_region:
                return jsonify({"error": "Region name must be unique"}), 400
        region.name = data["name"]
    if "description" in data:
        region.description = data["description"]

    db.session.commit()
    return jsonify(region.to_dict())

@region_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete regions
def delete_region(id):
    region = Region.query.get_or_404(id)
    # Add check for associated schools if needed before deletion
    # if region.schools:
    #     return jsonify({"error": "Cannot delete region with associated schools"}), 400
    db.session.delete(region)
    db.session.commit()
    return jsonify({"message": "Region deleted successfully"})

