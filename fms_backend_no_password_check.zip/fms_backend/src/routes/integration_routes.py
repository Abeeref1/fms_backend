# src/routes/integration_routes.py
from flask import Blueprint, jsonify, current_app
from .. import db
from ..models import Invoice, WorkOrder, Asset
from ..services import integration_service # Import the placeholder service
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

integration_bp = Blueprint("integration_bp", __name__, url_prefix="/api/v1/integrations")

# --- SAP Routes --- 

@integration_bp.route("/sap/push_invoice/<int:invoice_id>", methods=["POST"])
@manager_required # Only Admin or Manager can trigger integrations
def trigger_push_invoice_to_sap(invoice_id):
    """Triggers the placeholder function to push an invoice to SAP."""
    invoice = Invoice.query.get_or_404(invoice_id)
    try:
        result = integration_service.push_invoice_to_sap(invoice)
        status_code = 200 if result.get("status") == "success" else 500
        return jsonify(result), status_code
    except Exception as e:
        current_app.logger.error(f"Error triggering SAP invoice push for ID {invoice_id}: {e}")
        return jsonify({"error": "Failed to trigger SAP invoice push", "details": str(e)}), 500

@integration_bp.route("/sap/payment_status/<int:invoice_id>", methods=["GET"])
@manager_required # Only Admin or Manager can trigger integrations
def trigger_fetch_payment_status_from_sap(invoice_id):
    """Triggers the placeholder function to fetch payment status from SAP."""
    # Check if invoice exists, though the service only needs the ID for the placeholder
    Invoice.query.get_or_404(invoice_id) 
    try:
        result = integration_service.fetch_payment_status_from_sap(invoice_id)
        status_code = 200 if result.get("status") == "success" else 500
        # Include the simulated payment status in the response
        return jsonify(result), status_code
    except Exception as e:
        current_app.logger.error(f"Error triggering SAP payment status fetch for ID {invoice_id}: {e}")
        return jsonify({"error": "Failed to trigger SAP payment status fetch", "details": str(e)}), 500

# --- Maximo Routes --- 

@integration_bp.route("/maximo/create_work_order/<int:work_order_id>", methods=["POST"])
@manager_required # Only Admin or Manager can trigger integrations
def trigger_create_work_order_in_maximo(work_order_id):
    """Triggers the placeholder function to create a work order in Maximo."""
    work_order = WorkOrder.query.get_or_404(work_order_id)
    try:
        result = integration_service.create_work_order_in_maximo(work_order)
        status_code = 200 if result.get("status") == "success" else 500
        return jsonify(result), status_code
    except Exception as e:
        current_app.logger.error(f"Error triggering Maximo work order creation for ID {work_order_id}: {e}")
        return jsonify({"error": "Failed to trigger Maximo work order creation", "details": str(e)}), 500

@integration_bp.route("/maximo/update_work_order_status/<int:work_order_id>", methods=["PATCH"])
@manager_required # Only Admin or Manager can trigger integrations
def trigger_update_work_order_status_in_maximo(work_order_id):
    """Triggers the placeholder function to update work order status in Maximo."""
    work_order = WorkOrder.query.get_or_404(work_order_id)
    try:
        result = integration_service.update_work_order_status_in_maximo(work_order)
        status_code = 200 if result.get("status") != "error" else 500 # Allow "skipped" status
        return jsonify(result), status_code
    except Exception as e:
        current_app.logger.error(f"Error triggering Maximo work order status update for ID {work_order_id}: {e}")
        return jsonify({"error": "Failed to trigger Maximo work order status update", "details": str(e)}), 500

@integration_bp.route("/maximo/sync_asset/<string:external_asset_id>", methods=["POST"])
@manager_required # Only Admin or Manager can trigger integrations
def trigger_sync_asset_from_maximo(external_asset_id):
    """Triggers the placeholder function to sync asset data from Maximo."""
    try:
        result = integration_service.sync_asset_from_maximo(external_asset_id)
        status_code = 200 if result.get("status") == "success" else 500
        # The service placeholder includes simulated asset details
        return jsonify(result), status_code
    except Exception as e:
        current_app.logger.error(f"Error triggering Maximo asset sync for external ID {external_asset_id}: {e}")
        return jsonify({"error": "Failed to trigger Maximo asset sync", "details": str(e)}), 500

