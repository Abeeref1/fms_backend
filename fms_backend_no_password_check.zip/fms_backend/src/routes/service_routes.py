from flask import Blueprint, request, jsonify
from .. import db
from ..models import Service
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

service_bp = Blueprint("service_bp", __name__, url_prefix="/api/v1/services")

@service_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view services
def get_services():
    services = Service.query.all()
    return jsonify([s.to_dict() for s in services])

@service_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create services
def create_service():
    data = request.get_json()
    if not data or not data.get("name"):
        return jsonify({"error": "Service name is required"}), 400

    new_service = Service(
        name=data["name"],
        description=data.get("description"),
        frequency=data.get("frequency"),
        cost=data.get("cost")
    )
    db.session.add(new_service)
    db.session.commit()
    return jsonify(new_service.to_dict()), 201

@service_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific service
def get_service(id):
    service = Service.query.get_or_404(id)
    return jsonify(service.to_dict())

@service_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update services
def update_service(id):
    service = Service.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        service.name = data["name"]
    if "description" in data:
        service.description = data["description"]
    if "frequency" in data:
        service.frequency = data["frequency"]
    if "cost" in data:
        service.cost = data["cost"]

    db.session.commit()
    return jsonify(service.to_dict())

@service_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete services
def delete_service(id):
    service = Service.query.get_or_404(id)
    # Add check for associated SLAs if needed
    db.session.delete(service)
    db.session.commit()
    return jsonify({"message": "Service deleted successfully"})

