from flask import Blueprint, request, jsonify
from .. import db
from ..models import KPI
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

kpi_bp = Blueprint("kpi_bp", __name__, url_prefix="/api/v1/kpis")

@kpi_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view KPIs
def get_kpis():
    kpis = KPI.query.all()
    return jsonify([kpi.to_dict() for kpi in kpis])

@kpi_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create KPIs
def create_kpi():
    data = request.get_json()
    if not data or not data.get("name") or not data.get("category") or not data.get("measurement_unit"):
        return jsonify({"error": "Name, category, and measurement_unit are required"}), 400

    try:
        target_value = float(data["target_value"]) if data.get("target_value") is not None else None
    except (ValueError, TypeError):
        return jsonify({"error": "Target value must be a valid number"}), 400

    new_kpi = KPI(
        name=data["name"],
        description=data.get("description"),
        category=data["category"],
        measurement_unit=data["measurement_unit"],
        target_value=target_value,
        target_period=data.get("target_period")
    )
    db.session.add(new_kpi)
    db.session.commit()
    return jsonify(new_kpi.to_dict()), 201

@kpi_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific KPI
def get_kpi(id):
    kpi = KPI.query.get_or_404(id)
    return jsonify(kpi.to_dict())

@kpi_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update KPIs
def update_kpi(id):
    kpi = KPI.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        kpi.name = data["name"]
    if "description" in data:
        kpi.description = data["description"]
    if "category" in data:
        kpi.category = data["category"]
    if "measurement_unit" in data:
        kpi.measurement_unit = data["measurement_unit"]
    if "target_value" in data:
        try:
            kpi.target_value = float(data["target_value"]) if data["target_value"] is not None else None
        except (ValueError, TypeError):
            return jsonify({"error": "Target value must be a valid number"}), 400
    if "target_period" in data:
        kpi.target_period = data["target_period"]

    db.session.commit()
    return jsonify(kpi.to_dict())

@kpi_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete KPIs
def delete_kpi(id):
    kpi = KPI.query.get_or_404(id)
    # Results are deleted via cascade
    db.session.delete(kpi)
    db.session.commit()
    return jsonify({"message": "KPI deleted successfully"})

