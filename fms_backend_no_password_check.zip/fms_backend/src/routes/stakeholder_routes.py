from flask import Blueprint, request, jsonify
from .. import db
from ..models import Stakeholder, School
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

stakeholder_bp = Blueprint("stakeholder_bp", __name__, url_prefix="/api/v1/stakeholders")

@stakeholder_bp.route("", methods=["GET"])
@manager_required # Only Admin or Manager can view all stakeholders
def get_stakeholders():
    stakeholders = Stakeholder.query.all()
    return jsonify([s.to_dict() for s in stakeholders])

@stakeholder_bp.route("", methods=["POST"])
@admin_required # Only Admin can create new stakeholders (users)
def create_stakeholder():
    data = request.get_json()
    if not data or not data.get("name") or not data.get("role") or not data.get("contact_email") or not data.get("password"):
        return jsonify({"error": "Name, role, contact_email, and password are required"}), 400

    # Validate role
    allowed_roles = ["Admin", "Manager", "Technician"]
    if data["role"] not in allowed_roles:
        return jsonify({"error": f"Invalid role. Allowed roles: {', '.join(allowed_roles)}"}), 400

    if data.get("school_id"):
        school = School.query.get(data["school_id"])
        if not school:
            return jsonify({"error": "School not found"}), 404

    existing_stakeholder = Stakeholder.query.filter_by(contact_email=data["contact_email"]).first()
    if existing_stakeholder:
        return jsonify({"error": "Contact email must be unique"}), 400

    new_stakeholder = Stakeholder(
        name=data["name"],
        role=data["role"],
        contact_email=data["contact_email"],
        contact_phone=data.get("contact_phone"),
        school_id=data.get("school_id")
    )
    new_stakeholder.set_password(data["password"]) # Set hashed password
    db.session.add(new_stakeholder)
    db.session.commit()
    return jsonify(new_stakeholder.to_dict()), 201

@stakeholder_bp.route("/<int:id>", methods=["GET"])
@manager_required # Only Admin or Manager can view a specific stakeholder
def get_stakeholder(id):
    stakeholder = Stakeholder.query.get_or_404(id)
    return jsonify(stakeholder.to_dict())

@stakeholder_bp.route("/<int:id>", methods=["PUT"])
@admin_required # Only Admin can update stakeholders
def update_stakeholder(id):
    stakeholder = Stakeholder.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        stakeholder.name = data["name"]
    if "role" in data:
        # Validate role
        allowed_roles = ["Admin", "Manager", "Technician"]
        if data["role"] not in allowed_roles:
            return jsonify({"error": f"Invalid role. Allowed roles: {', '.join(allowed_roles)}"}), 400
        stakeholder.role = data["role"]
    if "contact_email" in data:
        if data["contact_email"] != stakeholder.contact_email:
            existing_stakeholder = Stakeholder.query.filter_by(contact_email=data["contact_email"]).first()
            if existing_stakeholder:
                return jsonify({"error": "Contact email must be unique"}), 400
        stakeholder.contact_email = data["contact_email"]
    if "contact_phone" in data:
        stakeholder.contact_phone = data["contact_phone"]
    if "school_id" in data:
        if data["school_id"]:
            school = School.query.get(data["school_id"])
            if not school:
                return jsonify({"error": "School not found"}), 404
        stakeholder.school_id = data["school_id"]
    # Allow password update (optional)
    if "password" in data and data["password"]:
        stakeholder.set_password(data["password"])

    db.session.commit()
    return jsonify(stakeholder.to_dict())

@stakeholder_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete stakeholders
def delete_stakeholder(id):
    stakeholder = Stakeholder.query.get_or_404(id)
    # Add checks? e.g., cannot delete the last admin?
    db.session.delete(stakeholder)
    db.session.commit()
    return jsonify({"message": "Stakeholder deleted successfully"})

