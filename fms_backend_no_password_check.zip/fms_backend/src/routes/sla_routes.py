from flask import Blueprint, request, jsonify
from .. import db
from ..models import SLA, Service
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

sla_bp = Blueprint("sla_bp", __name__, url_prefix="/api/v1/slas")

@sla_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view SLAs
def get_slas():
    slas = SLA.query.all()
    return jsonify([sla.to_dict() for sla in slas])

@sla_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create SLAs
def create_sla():
    data = request.get_json()
    if not data or not data.get("name") or not data.get("metric") or not data.get("target"):
        return jsonify({"error": "Name, metric, and target are required"}), 400

    if data.get("service_id"):
        service = Service.query.get(data["service_id"])
        if not service:
            return jsonify({"error": "Service not found"}), 404

    new_sla = SLA(
        name=data["name"],
        description=data.get("description"),
        metric=data["metric"],
        target=data["target"],
        service_id=data.get("service_id")
    )
    db.session.add(new_sla)
    db.session.commit()
    return jsonify(new_sla.to_dict()), 201

@sla_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific SLA
def get_sla(id):
    sla = SLA.query.get_or_404(id)
    return jsonify(sla.to_dict())

@sla_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update SLAs
def update_sla(id):
    sla = SLA.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        sla.name = data["name"]
    if "description" in data:
        sla.description = data["description"]
    if "metric" in data:
        sla.metric = data["metric"]
    if "target" in data:
        sla.target = data["target"]
    if "service_id" in data:
        if data["service_id"]:
            service = Service.query.get(data["service_id"])
            if not service:
                return jsonify({"error": "Service not found"}), 404
        sla.service_id = data["service_id"]

    db.session.commit()
    return jsonify(sla.to_dict())

@sla_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete SLAs
def delete_sla(id):
    sla = SLA.query.get_or_404(id)
    # Results are deleted via cascade
    db.session.delete(sla)
    db.session.commit()
    return jsonify({"message": "SLA deleted successfully"})

