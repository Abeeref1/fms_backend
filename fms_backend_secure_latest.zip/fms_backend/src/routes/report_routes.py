# src/routes/report_routes.py
from flask import Blueprint, jsonify, current_app
from .. import db
from ..models import WorkOrder, Asset, Invoice
from sqlalchemy import func
from collections import defaultdict
from datetime import date
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

report_bp = Blueprint("report_bp", __name__, url_prefix="/api/v1/reports")

@report_bp.route("/work_order_status", methods=["GET"])
@manager_required # Only Admin or Manager can view reports
def work_order_status_report():
    """Generates a report counting work orders by their current status."""
    try:
        status_counts = db.session.query(
            WorkOrder.status, 
            func.count(WorkOrder.id)
        ).group_by(WorkOrder.status).all()
        
        # Convert to a dictionary for easier JSON serialization
        report_data = dict(status_counts)
        
        return jsonify(report_data)
    except Exception as e:
        current_app.logger.error(f"Error generating work order status report: {e}")
        return jsonify({"error": "Failed to generate work order status report", "details": str(e)}), 500

@report_bp.route("/asset_count_by_type", methods=["GET"])
@manager_required # Only Admin or Manager can view reports
def asset_count_by_type_report():
    """Generates a report counting assets grouped by their type."""
    try:
        type_counts = db.session.query(
            Asset.asset_type, # Corrected from Asset.type
            func.count(Asset.id)
        ).group_by(Asset.asset_type).all()
        
        # Convert to a dictionary
        report_data = dict(type_counts)
        
        return jsonify(report_data)
    except Exception as e:
        current_app.logger.error(f"Error generating asset count by type report: {e}")
        return jsonify({"error": "Failed to generate asset count by type report", "details": str(e)}), 500

@report_bp.route("/monthly_cost_summary", methods=["GET"])
@manager_required # Only Admin or Manager can view reports
def monthly_cost_summary_report():
    """Generates a report summarizing total invoice costs per month."""
    try:
        # Query total cost grouped by year and month of the invoice period start date
        cost_summary = db.session.query(
            func.extract("year", Invoice.invoice_period_start).label("year"),
            func.extract("month", Invoice.invoice_period_start).label("month"),
            func.sum(Invoice.total_cost).label("total_cost")
        ).group_by(
            func.extract("year", Invoice.invoice_period_start),
            func.extract("month", Invoice.invoice_period_start)
        ).order_by(
            func.extract("year", Invoice.invoice_period_start),
            func.extract("month", Invoice.invoice_period_start)
        ).all()

        # Format the data for easier consumption (e.g., "YYYY-MM": cost)
        report_data = {
            f"{int(year)}-{int(month):02d}": cost 
            for year, month, cost in cost_summary
        }

        return jsonify(report_data)
    except Exception as e:
        current_app.logger.error(f"Error generating monthly cost summary report: {e}")
        return jsonify({"error": "Failed to generate monthly cost summary report", "details": str(e)}), 500

