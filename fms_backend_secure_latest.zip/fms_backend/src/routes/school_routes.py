from flask import Blueprint, request, jsonify
from .. import db
from ..models import School, Region
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

school_bp = Blueprint("school_bp", __name__, url_prefix="/api/v1/schools")

@school_bp.route("", methods=["GET"])
@technician_required # All authenticated users (Admin, Manager, Technician) can view schools
def get_schools():
    schools = School.query.all()
    return jsonify([school.to_dict() for school in schools])

@school_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can create schools
def create_school():
    data = request.get_json()
    if not data or not data.get("name") or not data.get("region_id"):
        return jsonify({"error": "School name and region_id are required"}), 400

    region = Region.query.get(data["region_id"])
    if not region:
        return jsonify({"error": "Region not found"}), 404

    existing_school = School.query.filter_by(name=data["name"]).first()
    if existing_school:
        return jsonify({"error": "School name must be unique"}), 400

    new_school = School(
        name=data["name"],
        address=data.get("address"),
        contact_person=data.get("contact_person"),
        contact_email=data.get("contact_email"),
        contact_phone=data.get("contact_phone"),
        region_id=data["region_id"]
    )
    db.session.add(new_school)
    db.session.commit()
    return jsonify(new_school.to_dict()), 201

@school_bp.route("/<int:id>", methods=["GET"])
@technician_required # All authenticated users can view a specific school
def get_school(id):
    school = School.query.get_or_404(id)
    return jsonify(school.to_dict())

@school_bp.route("/<int:id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update schools
def update_school(id):
    school = School.query.get_or_404(id)
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "name" in data:
        if data["name"] != school.name:
            existing_school = School.query.filter_by(name=data["name"]).first()
            if existing_school:
                return jsonify({"error": "School name must be unique"}), 400
        school.name = data["name"]
    if "address" in data:
        school.address = data["address"]
    if "contact_person" in data:
        school.contact_person = data["contact_person"]
    if "contact_email" in data:
        school.contact_email = data["contact_email"]
    if "contact_phone" in data:
        school.contact_phone = data["contact_phone"]
    if "region_id" in data:
        region = Region.query.get(data["region_id"])
        if not region:
            return jsonify({"error": "Region not found"}), 404
        school.region_id = data["region_id"]

    db.session.commit()
    return jsonify(school.to_dict())

@school_bp.route("/<int:id>", methods=["DELETE"])
@admin_required # Only Admin can delete schools
def delete_school(id):
    school = School.query.get_or_404(id)
    # Add checks for associated assets, work orders etc. if needed
    # if school.assets or school.work_orders:
    #     return jsonify({"error": "Cannot delete school with associated records"}), 400
    db.session.delete(school)
    db.session.commit()
    return jsonify({"message": "School deleted successfully"})

