from flask import Blueprint, request, jsonify
from .. import db
from ..models import WorkOrder, WorkOrderCost
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

work_order_cost_bp = Blueprint("work_order_cost_bp", __name__, url_prefix="/api/v1/work-orders/<int:work_order_id>/costs")

@work_order_cost_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view costs for a work order
def get_work_order_costs(work_order_id):
    work_order = WorkOrder.query.get_or_404(work_order_id)
    costs = work_order.costs
    return jsonify([cost.to_dict() for cost in costs])

@work_order_cost_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can add costs to a work order
def add_work_order_cost(work_order_id):
    work_order = WorkOrder.query.get_or_404(work_order_id)
    data = request.get_json()
    if not data or not data.get("cost_type") or data.get("amount") is None:
        return jsonify({"error": "cost_type and amount are required"}), 400

    try:
        amount = float(data["amount"])
    except ValueError:
        return jsonify({"error": "Amount must be a valid number"}), 400

    new_cost = WorkOrderCost(
        work_order_id=work_order_id,
        cost_type=data["cost_type"],
        description=data.get("description"),
        amount=amount
    )
    db.session.add(new_cost)
    db.session.commit()
    return jsonify(new_cost.to_dict()), 201

@work_order_cost_bp.route("/<int:cost_id>", methods=["GET"])
@technician_required # All authenticated users can view a specific cost
def get_work_order_cost(work_order_id, cost_id):
    cost = WorkOrderCost.query.filter_by(id=cost_id, work_order_id=work_order_id).first_or_404()
    return jsonify(cost.to_dict())

@work_order_cost_bp.route("/<int:cost_id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update costs
def update_work_order_cost(work_order_id, cost_id):
    cost = WorkOrderCost.query.filter_by(id=cost_id, work_order_id=work_order_id).first_or_404()
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "cost_type" in data:
        cost.cost_type = data["cost_type"]
    if "description" in data:
        cost.description = data["description"]
    if "amount" in data:
        try:
            cost.amount = float(data["amount"])
        except ValueError:
            return jsonify({"error": "Amount must be a valid number"}), 400

    db.session.commit()
    return jsonify(cost.to_dict())

@work_order_cost_bp.route("/<int:cost_id>", methods=["DELETE"])
@admin_required # Only Admin can delete costs
def delete_work_order_cost(work_order_id, cost_id):
    cost = WorkOrderCost.query.filter_by(id=cost_id, work_order_id=work_order_id).first_or_404()
    db.session.delete(cost)
    db.session.commit()
    return jsonify({"message": "Work order cost deleted successfully"})

