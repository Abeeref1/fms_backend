from flask import Blueprint, request, jsonify
from .. import db
from ..models import KPI, KPIResult
from datetime import date
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

kpi_result_bp = Blueprint("kpi_result_bp", __name__, url_prefix="/api/v1/kpis/<int:kpi_id>/results")

@kpi_result_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view KPI results
def get_kpi_results(kpi_id):
    kpi = KPI.query.get_or_404(kpi_id)
    results = kpi.results
    return jsonify([result.to_dict() for result in results])

@kpi_result_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can add KPI results
def add_kpi_result(kpi_id):
    kpi = KPI.query.get_or_404(kpi_id)
    data = request.get_json()
    if not data or data.get("value") is None or not data.get("measurement_date"):
        return jsonify({"error": "value and measurement_date are required"}), 400

    try:
        measurement_date = date.fromisoformat(data["measurement_date"])
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid measurement_date format. Use YYYY-MM-DD."}), 400

    try:
        value = float(data["value"])
    except ValueError:
        return jsonify({"error": "Value must be a valid number"}), 400

    new_result = KPIResult(
        kpi_id=kpi_id,
        measurement_date=measurement_date,
        value=value,
        notes=data.get("notes")
    )
    db.session.add(new_result)
    db.session.commit()
    return jsonify(new_result.to_dict()), 201

@kpi_result_bp.route("/<int:result_id>", methods=["GET"])
@technician_required # All authenticated users can view a specific KPI result
def get_kpi_result(kpi_id, result_id):
    result = KPIResult.query.filter_by(id=result_id, kpi_id=kpi_id).first_or_404()
    return jsonify(result.to_dict())

@kpi_result_bp.route("/<int:result_id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update KPI results
def update_kpi_result(kpi_id, result_id):
    result = KPIResult.query.filter_by(id=result_id, kpi_id=kpi_id).first_or_404()
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "measurement_date" in data:
        try:
            result.measurement_date = date.fromisoformat(data["measurement_date"]) if data["measurement_date"] else None
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid measurement_date format. Use YYYY-MM-DD."}), 400
    if "value" in data:
        try:
            result.value = float(data["value"])
        except ValueError:
            return jsonify({"error": "Value must be a valid number"}), 400
    if "notes" in data:
        result.notes = data["notes"]

    db.session.commit()
    return jsonify(result.to_dict())

@kpi_result_bp.route("/<int:result_id>", methods=["DELETE"])
@admin_required # Only Admin can delete KPI results
def delete_kpi_result(kpi_id, result_id):
    result = KPIResult.query.filter_by(id=result_id, kpi_id=kpi_id).first_or_404()
    db.session.delete(result)
    db.session.commit()
    return jsonify({"message": "KPI result deleted successfully"})

