from flask import Blueprint, request, jsonify
from .. import db
from ..models import SLA, SLAResult
from datetime import date
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

sla_result_bp = Blueprint("sla_result_bp", __name__, url_prefix="/api/v1/slas/<int:sla_id>/results")

@sla_result_bp.route("", methods=["GET"])
@technician_required # All authenticated users can view SLA results
def get_sla_results(sla_id):
    sla = SLA.query.get_or_404(sla_id)
    results = sla.results
    return jsonify([result.to_dict() for result in results])

@sla_result_bp.route("", methods=["POST"])
@manager_required # Only Admin or Manager can add SLA results
def add_sla_result(sla_id):
    sla = SLA.query.get_or_404(sla_id)
    data = request.get_json()
    if not data or not data.get("value") or data.get("achieved") is None or not data.get("measurement_date"):
        return jsonify({"error": "value, achieved status, and measurement_date are required"}), 400

    try:
        measurement_date = date.fromisoformat(data["measurement_date"])
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid measurement_date format. Use YYYY-MM-DD."}), 400

    if not isinstance(data["achieved"], bool):
        return jsonify({"error": "achieved must be a boolean (true/false)"}), 400

    new_result = SLAResult(
        sla_id=sla_id,
        measurement_date=measurement_date,
        value=data["value"],
        achieved=data["achieved"],
        notes=data.get("notes")
    )
    db.session.add(new_result)
    db.session.commit()
    return jsonify(new_result.to_dict()), 201

@sla_result_bp.route("/<int:result_id>", methods=["GET"])
@technician_required # All authenticated users can view a specific SLA result
def get_sla_result(sla_id, result_id):
    result = SLAResult.query.filter_by(id=result_id, sla_id=sla_id).first_or_404()
    return jsonify(result.to_dict())

@sla_result_bp.route("/<int:result_id>", methods=["PUT"])
@manager_required # Only Admin or Manager can update SLA results
def update_sla_result(sla_id, result_id):
    result = SLAResult.query.filter_by(id=result_id, sla_id=sla_id).first_or_404()
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    if "measurement_date" in data:
        try:
            result.measurement_date = date.fromisoformat(data["measurement_date"]) if data["measurement_date"] else None
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid measurement_date format. Use YYYY-MM-DD."}), 400
    if "value" in data:
        result.value = data["value"]
    if "achieved" in data:
        if not isinstance(data["achieved"], bool):
            return jsonify({"error": "achieved must be a boolean (true/false)"}), 400
        result.achieved = data["achieved"]
    if "notes" in data:
        result.notes = data["notes"]

    db.session.commit()
    return jsonify(result.to_dict())

@sla_result_bp.route("/<int:result_id>", methods=["DELETE"])
@admin_required # Only Admin can delete SLA results
def delete_sla_result(sla_id, result_id):
    result = SLAResult.query.filter_by(id=result_id, sla_id=sla_id).first_or_404()
    db.session.delete(result)
    db.session.commit()
    return jsonify({"message": "SLA result deleted successfully"})

