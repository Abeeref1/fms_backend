from flask import Blueprint, request, jsonify, current_app, make_response
from .. import db
from ..models import Invoice, School, WorkOrder, WorkOrderCost
from datetime import date, datetime, timedelta # Added timedelta
from calendar import monthrange
import csv
import io
from flask_jwt_extended import jwt_required # Import jwt_required
from ..utils.decorators import admin_required, manager_required, technician_required # Import role decorators

invoice_bp = Blueprint("invoice_bp", __name__, url_prefix="/api/v1/invoices")

@invoice_bp.route("", methods=["GET"])
@manager_required # Only Admin or Manager can view invoices
def get_invoices():
    invoices = Invoice.query.order_by(Invoice.generation_date.desc()).all()
    return jsonify([inv.to_dict() for inv in invoices])

@invoice_bp.route("/<int:id>", methods=["GET"])
@manager_required # Only Admin or Manager can view a specific invoice
def get_invoice(id):
    invoice = Invoice.query.get_or_404(id)
    return jsonify(invoice.to_dict())

@invoice_bp.route("/generate", methods=["POST"])
@manager_required # Only Admin or Manager can generate invoices
def generate_monthly_invoices():
    # Get year and month from request args, default to previous month
    try:
        year = request.args.get("year", type=int)
        month = request.args.get("month", type=int)

        if not year or not month:
            today = date.today()
            first_day_current_month = today.replace(day=1)
            last_day_prev_month = first_day_current_month - timedelta(days=1)
            year = last_day_prev_month.year
            month = last_day_prev_month.month
        elif not (1 <= month <= 12):
             return jsonify({"error": "Invalid month specified"}), 400

        # Calculate date range for the specified month and year
        _, last_day = monthrange(year, month)
        first_day_target_month = date(year, month, 1)
        last_day_target_month = date(year, month, last_day)

    except ValueError:
        return jsonify({"error": "Invalid year or month format"}), 400

    schools = School.query.all()
    generated_invoices = []
    errors = []

    for school in schools:
        # Check if invoice already exists for this period
        existing_invoice = Invoice.query.filter_by(
            school_id=school.id,
            invoice_period_start=first_day_target_month,
            invoice_period_end=last_day_target_month
        ).first()

        if existing_invoice:
            errors.append(f"Invoice already exists for {school.name} for {month:02d}/{year}")
            continue

        # Calculate costs
        # 1. Work Order Costs (Based on completed WOs in the period)
        work_order_cost_total = db.session.query(db.func.sum(WorkOrderCost.amount)).join(WorkOrder).filter(
            WorkOrder.school_id == school.id,
            WorkOrder.completion_date >= first_day_target_month,
            WorkOrder.completion_date <= last_day_target_month,
            WorkOrder.status.in_(["Completed", "Closed"]) # Consider only completed/closed WOs
        ).scalar() or 0.0

        # --- Placeholder Costs --- 
        # TODO: Implement actual calculation logic based on Manpower, Consumables, Subcontractor models/data
        manpower_cost_total = 500.00 # Placeholder
        consumables_cost_total = 150.00 # Placeholder
        subcontractor_cost_total = 300.00 # Placeholder
        # --- End Placeholder Costs ---

        # Only generate invoice if there are costs (or if placeholders are non-zero)
        if work_order_cost_total > 0 or manpower_cost_total > 0 or consumables_cost_total > 0 or subcontractor_cost_total > 0:
            new_invoice = Invoice(
                school_id=school.id,
                invoice_period_start=first_day_target_month,
                invoice_period_end=last_day_target_month,
                manpower_cost=manpower_cost_total,
                work_order_cost=work_order_cost_total,
                consumables_cost=consumables_cost_total,
                subcontractor_cost=subcontractor_cost_total,
                notes=f"Auto-generated invoice for {month:02d}/{year}"
            )
            new_invoice.calculate_total() # Calculate total cost
            db.session.add(new_invoice)
            generated_invoices.append(new_invoice.to_dict())
        else:
            # Optional: Log or note schools with no costs for the period
            pass

    try:
        db.session.commit()
        return jsonify({
            "message": f"Invoice generation complete for {month:02d}/{year}",
            "generated_invoices": generated_invoices,
            "errors": errors
        }), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Invoice generation failed for {month:02d}/{year}: {e}")
        return jsonify({"error": "Invoice generation failed", "details": str(e)}), 500

@invoice_bp.route("/<int:id>/status", methods=["PUT"])
@manager_required # Only Admin or Manager can update invoice status
def update_invoice_status(id):
    invoice = Invoice.query.get_or_404(id)
    data = request.get_json()
    if not data or not data.get("status"):
        return jsonify({"error": "Status is required"}), 400

    # Add validation for allowed statuses if needed
    allowed_statuses = ["Generated", "Sent", "Paid", "Overdue", "Cancelled"]
    if data["status"] not in allowed_statuses:
        allowed_statuses_str = ", ".join(allowed_statuses)
        return jsonify({"error": f"Invalid status. Allowed statuses: {allowed_statuses_str}"}), 400

    invoice.status = data["status"]
    db.session.commit()
    return jsonify(invoice.to_dict())

@invoice_bp.route("/<int:id>/export/csv", methods=["GET"])
@manager_required # Only Admin or Manager can export invoices
def export_invoice_csv(id):
    invoice = Invoice.query.get_or_404(id)
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    writer.writerow(["Invoice ID", invoice.id])
    writer.writerow(["School Name", invoice.school.name if invoice.school else "N/A"])
    writer.writerow(["Period Start", invoice.invoice_period_start.isoformat() if invoice.invoice_period_start else "N/A"])
    writer.writerow(["Period End", invoice.invoice_period_end.isoformat() if invoice.invoice_period_end else "N/A"])
    writer.writerow(["Generation Date", invoice.generation_date.isoformat() if invoice.generation_date else "N/A"])
    writer.writerow(["Status", invoice.status])
    writer.writerow([]) # Blank line
    writer.writerow(["Cost Component", "Amount"])
    writer.writerow(["Manpower Cost", invoice.manpower_cost])
    writer.writerow(["Work Order Cost", invoice.work_order_cost])
    writer.writerow(["Consumables Cost", invoice.consumables_cost])
    writer.writerow(["Subcontractor Cost", invoice.subcontractor_cost])
    writer.writerow([]) # Blank line
    writer.writerow(["Total Cost", invoice.total_cost])
    writer.writerow([]) # Blank line
    writer.writerow(["Notes", invoice.notes])

    output.seek(0)
    
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = f"attachment; filename=invoice_{id}_{invoice.school.name if invoice.school else 'school'}.csv"
    response.headers["Content-type"] = "text/csv"
    
    return response

@invoice_bp.route("/<int:id>/export/pdf", methods=["GET"])
@manager_required # Only Admin or Manager can export invoices (when implemented)
def export_invoice_pdf(id):
    # Placeholder - PDF generation requires a library like FPDF2 or WeasyPrint
    invoice = Invoice.query.get_or_404(id)
    # TODO: Implement PDF generation logic here
    return jsonify({"error": "PDF export not implemented"}), 501

