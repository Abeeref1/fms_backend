from flask_sqlalchemy import SQLAlchemy

# Initialize extensions here to avoid circular imports
db = SQLAlchemy()

