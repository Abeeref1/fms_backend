from .. import db # Import db from parent package (src)
from datetime import datetime

class SLAResult(db.Model):
    __tablename__ = 'sla_results'
    id = db.Column(db.Integer, primary_key=True)
    sla_id = db.Column(db.Integer, db.ForeignKey('slas.id'), nullable=False)
    measurement_date = db.Column(db.Date, default=datetime.utcnow, nullable=False)
    value = db.Column(db.String(50), nullable=False) # Actual measured value
    achieved = db.Column(db.Boolean, nullable=False) # Whether the target was met
    notes = db.Column(db.Text, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'sla_id': self.sla_id,
            'measurement_date': self.measurement_date.isoformat() if self.measurement_date else None,
            'value': self.value,
            'achieved': self.achieved,
            'notes': self.notes
        }
