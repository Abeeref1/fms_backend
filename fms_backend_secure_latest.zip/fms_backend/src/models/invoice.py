from .. import db # Import db from parent package (src)
from datetime import datetime

class Invoice(db.Model):
    __tablename__ = 'invoices'
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer, db.ForeignKey('schools.id'), nullable=False)
    invoice_period_start = db.Column(db.Date, nullable=False)
    invoice_period_end = db.Column(db.Date, nullable=False)
    generation_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Generated') # e.g., Generated, Sent, Paid, Overdue
    manpower_cost = db.Column(db.Float, default=0.0)
    work_order_cost = db.Column(db.Float, default=0.0)
    consumables_cost = db.Column(db.Float, default=0.0)
    subcontractor_cost = db.Column(db.Float, default=0.0)
    total_cost = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text, nullable=True)

    def calculate_total(self):
        # Basic calculation, can be expanded
        self.total_cost = (self.manpower_cost + 
                           self.work_order_cost + 
                           self.consumables_cost + 
                           self.subcontractor_cost)

    def to_dict(self):
        return {
            'id': self.id,
            'school_id': self.school_id,
            'school_name': self.school.name if self.school else None,
            'invoice_period_start': self.invoice_period_start.isoformat() if self.invoice_period_start else None,
            'invoice_period_end': self.invoice_period_end.isoformat() if self.invoice_period_end else None,
            'generation_date': self.generation_date.isoformat() if self.generation_date else None,
            'status': self.status,
            'manpower_cost': self.manpower_cost,
            'work_order_cost': self.work_order_cost,
            'consumables_cost': self.consumables_cost,
            'subcontractor_cost': self.subcontractor_cost,
            'total_cost': self.total_cost,
            'notes': self.notes
        }
